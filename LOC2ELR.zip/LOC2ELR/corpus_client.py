from pathlib import Path
from typing import Iterator, Union
import gzip
import json
import io
import logging
import zipfile
import pandas as pd
from utils import INPUT_METHOD


class CORPUSClientError(Exception):
    """Base error for corpus I/O."""

class ZipFileNotFoundError(CORPUSClientError):
    pass


DEFAULT_ENCODING = "latin-1"
log = logging.getLogger(__name__)



def _open_file(file_path: Union[str, Path], encoding: str = DEFAULT_ENCODING) -> pd.DataFrame:
    """
    Loads the CORPUS file, given a range of formats.
    """
    p = Path(file_path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")

    suffixes = p.suffixes
    is_gz = suffixes and suffixes[-1] == ".gz"

    fmt = (suffixes[-2] if is_gz and len(suffixes) > 1 else suffixes[-1]).lstrip('.')

    reader = INPUT_METHOD.get(fmt)
    if reader is None:
        raise CORPUSClientError(f"Unsupported format: .{fmt}")

    if fmt == "json":
        if is_gz:
            with gzip.open(p, "rb") as gz_fh:
                text = gz_fh.read().decode(encoding)
        else:
            text = p.read_text(encoding=encoding)
        data = json.loads(text)
        if isinstance(data, dict) and "TIPLOCDATA" in data:
            data = data["TIPLOCDATA"]
        elif isinstance(data, dict) and len(data) == 1:
            data = next(iter(data.values()))
        return pd.json_normalize(data)
    else:
        if is_gz:
            with gzip.open(p, "rb") as gz_fh:
                raw = gz_fh.read()
            buffer = io.BytesIO(raw)
            return reader(buffer)
        return reader(p)

    


def get_corpus(input_path:str):

    df = _open_file(input_path)
    """
    if output_path and output_format:
        out_path = Path(output_path).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            OUTPUT_METHOD[output_format.lower()](df, f"{out_path}.{output_format}")
        except KeyError as exc:
            raise UnsupportedCacheFormatError(str(exc))
        except Exception as exc:
            raise CORPUSClientError(
                f"Could not write {output_format.upper()} to {out_path}: {exc}"
            ) from exc
    """
    return df