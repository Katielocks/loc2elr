from __future__ import annotations

import os
from pathlib import Path
from typing import Union, Optional

import geopandas as gpd
import pandas as pd
from shapely.geometry import Point

from corpus_client import get_corpus
from bplan_client import get_bplan
from ELR_client import get_elr
from utils import OUTPUT_METHOD
from config import settings as cfg



class   LOC2ELR(RuntimeError):
    """Raised whenever we can't fetch/unpack/parse the BPLAN doc."""


def add_elr_to_corpus(
    bplan_source: Union[str, Path],
    track_source: Union[str, Path],
    *,
    output_path: Optional[Union[str, Path]] = None,
    max_distance: float = 1000.0,          
    easting_col: str = "OS_EASTING",
    northing_col: str = "OS_NORTHING",
    loc_col: str = "STANOX",
    track_col: str = "TRACK_ID"
) -> pd.DataFrame:

    bplan_df = get_bplan(bplan_source)

    required_cols = {loc_col, easting_col, northing_col}
    missing = required_cols - set(bplan_df.columns)
    if missing:
        raise ValueError(f"BPlan missing required columns: {sorted(missing)}")

    track_path = get_elr(track_source)     
    track_gdf = gpd.read_file(track_path)

    osgb_crs = "EPSG:27700"
    if track_gdf.crs is None:
        track_gdf.set_crs(osgb_crs, inplace=True)
    track_gdf = track_gdf.to_crs(osgb_crs)

    if not isinstance(bplan_df, gpd.GeoDataFrame):
        bplan_gdf = gpd.GeoDataFrame(
            bplan_df,
            geometry=gpd.points_from_xy(bplan_df[easting_col],
                                        bplan_df[northing_col]),
            crs=osgb_crs,
        )
    else:
        bplan_gdf = bplan_df.to_crs(osgb_crs)
    nearest = gpd.sjoin_nearest(
        bplan_gdf,
        track_gdf[[track_col, "geometry"]],   
        how="left",
        max_distance=max_distance,
        distance_col=f"{track_col}_DISTANCE",
    )

    out_df = nearest[[loc_col,track_col]]

    if output_path:
        out_path = Path(output_path).expanduser().resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        output_format = output_path.lower.suffix()

        try:
            OUTPUT_METHOD[output_format.lower()](out_df, out_path)
        except KeyError as exc:
            raise (str(exc))
        except Exception as exc:
            raise  LOC2ELR(
                f"Could not write {output_format.upper()} to {out_path}: {exc}"
            ) from exc

add_elr_to_corpus()