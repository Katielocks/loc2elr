from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Any
import json

@dataclass(frozen=True)
class IOCfg:
    BPLAN: Path
    TRACK_MODEL: Path
    CORPUS: Path

@dataclass(frozen=True)
class ModelCfg:
    LOC_NAME: str
    MAX_DIST: float

@dataclass(frozen=True)
class Settings:
    io: Dict
    config: Dict


def _loadSettings() -> Settings:

    base_dir = Path(__file__).parent
    settings_path = base_dir / "settings.json"
    if not settings_path.exists():
        raise FileNotFoundError(f"Cannot find settings.json at {settings_path}")

    raw: dict[str, Any] = json.loads(settings_path.read_text())
    IOraw : dict[str, Any] = raw["io"]
    Modelraw : dict[str, Any] = raw["model"]

    IOsettings = IOCfg(
        BPLAN= IOraw["BPLAN"],
        TRACK_MODEL= Modelraw["TRACK_MODEL"]
    )


    ModelSettings = ModelCfg(
        Modelraw["LOC_NAME"],
        Modelraw["MAX_DIST"],
        )

    return Settings(
        io= IOsettings,
        model= ModelSettings
    )


settings: Settings = _loadSettings()
